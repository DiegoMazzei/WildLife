<?php

$router -> get('/dashboard', '/controllers/dashboard/dashboard.php');
$router -> get('/dashboard/schede', '/controllers/dashboard/schede.php');
$router -> get('/dashboard/operatori', '/controllers/dashboard/operatori.php');
$router -> get('/dashboard/storico', '/controllers/dashboard/storico.php');