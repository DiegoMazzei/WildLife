<header>
    <h1><?= $title ?></h1>

    <div class="header-buttons">
        <div class="profile">
            <img>
        </div>
    </div>
</header>
