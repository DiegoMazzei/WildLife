<?php $path = $root . '/views/dashboard/partials/';?>
<?php include_once($path . 'head.php'); ?>
<?php include_once($path . 'sidebar.php'); ?>
<?php include_once($path . 'header.php'); ?>

<main class="dashboardContent">
	<?php include_once($path . 'widget.php'); ?>
</main>

<?php include_once($path . 'foot.php'); ?>
